var myApp = angular.module('myApp', []);

myApp.controller('MyController', function MyController($scope) {
  $scope.employeeList = [
  {
    "name":"Karoonakar Jaiswal",
    "jobTitle":"Technical Manager",
    "company":"SG",
    "address":"Varanasi",
	"shortname":"kk"
  },
  {
    "name":"Bhupendra Singh",
    "jobTitle":"Technical Manager",
    "company":"SG",
    "address":"Agara",
	"shortname":"bb"
  },
  {
    "name":"Ankur Jain",
    "jobTitle":"Sr. Tech Lead",
    "company":"SG",
    "address":"Indore",
	"shortname":"aj"
  },
  {
    "name":"Manoj Chitagupi",
    "jobTitle":"Sr. Software Engineer",
    "company":"SG",
    "address":"Bangalore",
	"shortname":"mc"
  },
  {
    "name":"Shrinivas",
    "jobTitle":"Technical Manager",
    "company":"SG",
    "address":"Mangalore",
	"shortname":"sb"
  },
  {
    "name":"Anil Jha",
    "jobTitle":"Sr. Software Engineer",
    "company":"SG",
    "address":"Kolkata",
	"shortname":"ajha"
  }
]
});