(function () {
    "use strict";
	var app = angular.module("EmployeeModule",[]);
    angular
        .module("EmployeeModule")
        .controller("EmployeeListCtrl",
                    EmployeeListCtrl);

    function EmployeeListCtrl() {
        var vm = this;
        vm.employeeList = [
            {
				"name":"Karoonakar Jaiswal",
				"jobTitle":"Technical Manager",
				"company":"SG",
				"address":"Varanasi",
				"shortname":"kk"
            },
            {
                "name":"Manoj Chitagupi",
				"jobTitle":"Sr. Software Engineer",
				"company":"SG",
				"address":"Bangalore",
				"shortname":"mc"
            }];

        vm.showImage = false;

        vm.toggleImage = function() {
            vm.showImage = !vm.showImage;
        }
    }
}());
