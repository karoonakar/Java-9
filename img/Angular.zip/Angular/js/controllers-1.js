var myApp = angular.module('myApp', []);

myApp.controller('MyController', function MyController($scope) {
  $scope.employee = {
    'name' : 'Karoonakar Jaiswal',
    'job_title' : 'Technical Manager',
    'company' : 'SG'
  }
});