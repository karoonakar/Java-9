var myApp=angular.module('myApp', []);

myApp.controller('MyController',['$scope','$location','$log',
function($scope, $location, $log){
	$log.info($location.path());
	//console.log($location.path());
} ])